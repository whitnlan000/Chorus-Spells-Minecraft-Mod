scoreboard objectives add spell_using used:carrot_on_a_stick
scoreboard players add @a spell_using 0

execute as @a at @s if score @s spell_using matches 1.. if items entity @s weapon.mainhand carrot_on_a_stick[minecraft:enchantments={"spells:burn":1}] run function spells:burn-particles
execute as @a at @s if score @s spell_using matches 1.. if items entity @s weapon.mainhand carrot_on_a_stick[minecraft:enchantments={"spells:burn":1}] run execute as @e[distance=..5,type=!player] run data merge entity @s {Fire:60}

execute as @a at @s if score @s spell_using matches 1.. if items entity @s weapon.mainhand carrot_on_a_stick[minecraft:enchantments={"spells:strike":1}] run function spells:strike-particles
execute as @a at @s if score @s spell_using matches 1.. if items entity @s weapon.mainhand carrot_on_a_stick[minecraft:enchantments={"spells:strike":1}] run execute as @e[distance=..5,type=!player] run damage @s 5

execute as @a at @s if score @s spell_using matches 1.. if items entity @s weapon.mainhand carrot_on_a_stick[minecraft:enchantments={"spells:poison":1}] run function spells:poison-particles
execute as @a at @s if score @s spell_using matches 1.. if items entity @s weapon.mainhand carrot_on_a_stick[minecraft:enchantments={"spells:poison":1}] run execute as @e[distance=..5,type=!player] run effect give @s poison

execute as @a at @s if score @s spell_using matches 1.. if items entity @s weapon.mainhand carrot_on_a_stick[minecraft:enchantments={"spells:bolt":1}] run function spells:bolt-particles
execute as @a at @s if score @s spell_using matches 1.. if items entity @s weapon.mainhand carrot_on_a_stick[minecraft:enchantments={"spells:bolt":1}] run execute as @e[distance=..5,type=!player] at @s run summon lightning_bolt

execute if score @p spell_using matches 1.. run scoreboard players reset @p